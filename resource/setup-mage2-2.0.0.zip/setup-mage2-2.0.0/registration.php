<?php

/**
 * This file is part of the Setup package.
 *
 * (c) Sitewards GmbH
 */

\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'Sitewards_Setup',
    __DIR__
);
